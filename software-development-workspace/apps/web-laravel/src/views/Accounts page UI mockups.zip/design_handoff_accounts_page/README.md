# Handoff: Customer Account Detail Page (Konvergenz)

## Overview

A redesign of the customer account detail page (`Customers → Accounts → <Account>`) inside the Konvergenz admin app. The existing page renders every field at equal visual weight and is mostly em-dashes, so a user cannot tell at a glance whether an account is healthy, what is in flight, or what needs action.

The redesign keeps the same information architecture and the same tab set, and changes hierarchy:

- A **header band** carries identity (logo, name, status, tier, industry, location, owner) plus four KPI tiles: Closed won (lifetime), Open pipeline, Renewal date, Last contact.
- The Overview body becomes a **two-column layout**: pipeline, account details and activity timeline on the left; primary contact, an alert card, active policies and documents on the right.
- Empty data is replaced with real values wherever the system holds them; where nothing exists, the card states what is missing and offers the action instead of printing `—`.
- Every remaining tab is designed (previously only Overview existed as a real view).

## About the design files

`Accounts Page.dc.html` in this bundle is a **design reference created in HTML** — a prototype showing intended layout, styling and behavior. It is not production code to copy.

The task is to **recreate this design in the Konvergenz codebase** using its existing components, layout shell, and styling conventions (the app already has a sidebar shell, top bar, tables, buttons, badges and cards — reuse them). The HTML prototype uses inline styles and a small custom runtime purely so it could be authored quickly; none of that should ship.

`reference-current-page.png` is a screenshot of the page as it exists today, for comparison and for the shell chrome (sidebar nav, org switcher, Clock In, avatar) that the design reproduces.

## Fidelity

**High fidelity.** Colors, type sizes, spacing, radii and hover states in the prototype are final and are enumerated below. Recreate the UI closely — but resolve any conflict in favour of the codebase's existing components. Where the prototype's values differ trivially from an existing shared component (e.g. a button is 32px here and 34px in the app), use the app's component.

Sidebar and top-bar **icons in the prototype are geometric placeholders** (empty squares and circles). Use the real icon set already in the app; do not implement the placeholders.

## Screens / views

The page is one route with ten tabs. Tabs, in order, with the badge counts shown in the prototype:

`Overview` · `Contacts (3)` · `Account Contracts (4)` · `Activities (12)` · `Leads (3)` · `Opportunities (3)` · `Projects (4)` · `Support (4)` · `Travels (3)` · `Assigned Team (5)`

Counts come from the account's related-record totals; omit the badge when zero.

### Application shell (unchanged from today, reproduced for context)

- 4px bar across the very top, `#9b1c1c`.
- **Sidebar**: 244px, background `#fff`, right border `1px solid #e5e7eb`. Wordmark "KONVERGENZ" 17px / 800 / `letter-spacing:-0.4px` / `#d31c1c`, in a 19px 20px block with a `1px solid #f3f4f6` bottom border. Nav items: 13.5px `#374151`, padding 8px 10px, margin 0 10px, radius 7px, 11px gap to icon, hover `background:#f3f4f6`. Group labels ("PEOPLE", "OPERATIONS"): 10.5px / 700 / `letter-spacing:.08em` / `#6b7280`, padding 16px 20px 7px. Sub-items (Projects Dashboard, PM Task Definitions) indent to `margin-left:34px`, 13px, `#4b5563`. Active item (Customers): `background:#eff6ff`, `color:#2563eb`, weight 600. Footer row: 26px avatar circle `#eff6ff`/`#2563eb` + logout icon, `border-top:1px solid #f3f4f6`, padding 12px 20px.
- **Top bar**: height 60px, `#fff`, `border-bottom:1px solid #e5e7eb`, padding 0 24px. Left: "Org" label 12.5px `#6b7280` + org select (height 32, `1px solid #d1d5db`, radius 5, 12.5px `#111827`). Right: "Clock In" pill (height 34, radius 999, `#2563eb` → hover `#1d4ed8`, 13px/600 white), notification icon, theme icon, then 28px avatar `#2563eb` + "Admin" 13px/600 `#111827`.
- **Content area**: background `#f8f9fb`, padding 22px 28px 48px, `max-width:1360px`.

### Second toolbar (new)

Below the top bar: height 52px, `#fff`, `border-bottom:1px solid #e5e7eb`, padding 0 28px. Left: search field, max-width 420px, height 32, `background:#f8f9fb`, `1px solid #e5e7eb`, radius 6, placeholder 13px `#9ca3af` — "Search accounts, deals, contacts". Right: secondary button "Log activity" (height 32, `1px solid #d1d5db`, radius 6, 12.5px `#374151`, hover `#f3f4f6`) and primary "New deal" (height 32, `#2563eb`, radius 6, 12.5px/600 white, hover `#1d4ed8`).

If a global search already exists in the app shell, drop this row's search field and keep only the two actions, aligned right.

### Breadcrumb + header card

Breadcrumb: 12px, `Accounts` link `#6b7280` → `/` `#cbd5e1` → current `#0f172a`. Margin-bottom 14px.

Header card: `#fff`, `1px solid #e6eaf0`, radius 10, padding 22px 24px, margin-bottom 16px.

- Row 1 — 52×52 account logo tile (radius 10; prototype uses a text placeholder `AAR` on `#fdf2f2` with `1px solid #f4d6d6`, `#b91c1c` 11px/700 — replace with the stored account logo, falling back to initials), 18px gap, then:
  - `h1` 22px / 600 / `letter-spacing:-0.4px` / `#0f172a`.
  - Status pill: height 22, radius 999, `background:#ecfdf3`, `border:1px solid #abefc6`, `color:#067647`, 11.5px/600, with a 5px `#17b26a` dot. Tier pill: `#f4f6f8` / `1px solid #e6eaf0` / `#475569`.
  - Meta line, 7px below: 12.5px `#64748b`, `·` separators `#cbd5e1` — industry · location · "Client since <month year>" · "Owner <name>" (name in `#0f172a`/600).
  - Right-aligned action group, 8px gap: "☆ Follow" toggle (becomes "★ Following"), "Edit", and a `···` overflow button — all height 32, `1px solid #e6eaf0`, radius 7, 12.5px `#475569`, hover `#f4f6f8`.
- Row 2 — KPI strip, 22px below: 4-up grid, `gap:1px` on a `#e6eaf0` background with a `1px solid #e6eaf0` border and radius 9 (so cells read as hairline-separated). Each cell `#fff`, padding 14px 16px:
  - label 10.5px / 600 / `letter-spacing:.07em` / uppercase / `#94a3b8`
  - value 21px / 600 / `letter-spacing:-0.5px` / `#0f172a`
  - sub-line 11.5px — `#067647` for positive delta, `#b54708` for a warning (e.g. "31 days out"), `#64748b` neutral.
  - Cells: Closed won (lifetime) `KES 9.40M` / "↑ 18% vs last year" · Open pipeline `KES 6.37M` / "3 active deals" · Renewal date `30 Sep 2026` / "31 days out" · Last contact `4 days ago` / "Call · Wanjiru Kamau".

### Tab bar

Horizontal row, `border-bottom:1px solid #e6eaf0`, margin-bottom 20px, horizontally scrollable. Each tab: height 38, padding 0 13px, 13px. Inactive `#64748b` weight 450; active `#0f172a` weight 600 with `box-shadow: inset 0 -2px 0 #2563eb`. Count badge 11px `#94a3b8`, 7px gap.

### Tab: Overview

Two-column grid, `minmax(0,1.62fr) minmax(0,1fr)`, `gap:16px`, `align-items:start`. Both columns are vertical stacks with `gap:16px`. All cards: `#fff`, `1px solid #e6eaf0`, radius 10. Card headers: padding 15px 20px, `border-bottom:1px solid #eef1f5`, title 13.5px/600 `#0f172a`, right-side link 12.5px `#2563eb`.

**Left column**

1. **Pipeline** — header "Pipeline" + "View all 3" link. Then a stacked stage bar: 7px tall, radius 4, track `#eef1f5`, segments proportional to value with 1px white gaps — Negotiation `#2563eb` 29%, Proposal `#84b0f5` 66%, Qualification `#cbdcf9` 4%. Legend below, 11.5px `#64748b`, 7px square swatches. Then one row per deal (padding 11px 12px, radius 8, hover `#f8fafc`): name 13px/600, sub-line 11.5px `#64748b` ("Proposal sent · closes 30 Sep 2026"), right-aligned value 13px/600 in an 88px column, then a 104px progress column — 5px bar, track `#eef1f5`, fill `#2563eb` (`#84b0f5` under 25%), percentage 11px `#64748b`.
2. **Account details** — header "Account details" + "Edit". Body padding 18px 20px, two-column grid `gap: 2px 40px`. Each row: label 12.5px `#64748b` left, value 12.5px/500 `#0f172a` right, `space-between`, padding 8px 0, `border-bottom:1px solid #f4f6f8` (last row in each column has none). Fields: Client ID `ACC-100482`, Industry `Insurance & Health`, Customer type `Corporate — Broker led`, Employees covered `1,240`, Contact person `Wanjiru Kamau`, Payment terms `Net 30`, Account manager `Joan Mwangi`, Lead source `Broker referral`.
3. **Recent activity** (toggleable — see State) — header "Recent activity" + "Log activity". Timeline: per entry a 24px gutter with a 9px dot (`#2563eb` for the newest, `#cbd5e1` otherwise) and a 1px `#e6eaf0` connector; content 12.5px `#0f172a` with the type in 600, meta line 11.5px `#94a3b8` ("26 Aug 2026 · Joan Mwangi"). 18px bottom padding per entry, none on the last.

**Right column**

1. **Primary contact** — 40px initials avatar (`#eaf1fd` / `#1d4ed8`, 13px/600), name 13.5px/600, role 12px `#64748b`; then Email (link) and Phone rows 12.5px `space-between`; then two half-width buttons, 8px gap: "Email" primary `#2563eb`, "Call" secondary `1px solid #e6eaf0`. Header link "All 3".
   - Empty state (today's "Nobody recorded"): keep the card, show "No primary contact set" 12.5px `#64748b` and a single primary "Add contact" button — do not print `—`.
2. **Renewal alert** — `background:#fffbf5`, `border:1px solid #f7e0bd`, radius 10, padding 16px 18px. 7px `#f79009` dot + title 12.5px/600 `#7a3e0b` ("Renewal in 31 days"); body 12.5px/1.5 `#93500f`; two buttons — "Follow up" (`#fdf0da`, `1px solid #f7e0bd`, `#7a3e0b`, 600) and text button "Snooze" (`#93500f`), height 29, radius 6.
   - Show this card only when a renewal falls inside 60 days or an SLA/overdue condition is met. Suppress otherwise; do not render an empty shell.
3. **Active policies** — padding 18px 20px; per row policy name 12.5px `#0f172a` left, expiry 12px `#64748b` right, separated by 1px `#f4f6f8` rules.
4. **Documents** — header "Documents" + "Attach" link. Per row: 26px extension tile (`#f4f6f8`, `1px solid #e6eaf0`, radius 5, 8.5px/700 `#64748b`), filename 12.5px `#0f172a` with ellipsis truncation, meta 11px `#94a3b8` ("2.4 MB · 04 Jul 2025").

### Tab: Contacts

Single table card. Header "Contacts" + primary "Add contact" (height 30, radius 7). Column template `2fr 1.6fr 1.8fr 1.2fr 90px` — Name, Role, Email, Phone, Type. Header row: padding 10px 20px, `background:#fafbfc`, `border-bottom:1px solid #eef1f5`, 10.5px / 600 / uppercase / `letter-spacing:.06em` / `#94a3b8`. Body rows: padding 13px 20px, `border-bottom:1px solid #f4f6f8`, 12.5px, hover `#f8fafc`. Name cell = 28px initials avatar (`#eaf1fd`/`#1d4ed8`, 11px/600) + name 600 `#0f172a`. Email `#2563eb`, truncated. Type 11px `#64748b`.

### Tab: Account Contracts

Three summary cards above the table (padding 16px 18px; label 10.5px uppercase `#94a3b8`, value 20px/600): Contracted value `KES 12.60M`, Active contracts `3 of 4`, Next expiry `30 Sep 2026` in `#b54708`.

Table: `2.2fr 1.2fr 1.1fr 1.5fr 110px` — Contract, Type, Value (right), Term (right), Status (right). Contract cell = name 600 + reference 11px `#94a3b8` (`CT-2026-0114`). Status pill, height 21, radius 999, 11.5px/600, using the badge palette below. Header action: primary "New contract".

### Tab: Activities

One card, padding 20px, title "Activity history". Per row (padding 12px 0, `border-bottom:1px solid #f4f6f8`): 88px date column 11.5px `#94a3b8`; 82px type chip (height 20, radius 5, `#f4f6f8`, 11px/600 `#475569`) — Call / Email / Meeting / Note; then description 12.5px `#0f172a` and actor/duration 11.5px `#94a3b8`.

### Tab: Leads

Table `2fr 1.4fr 1.4fr 1fr 1fr` — Lead, Source, Owner, Score (right), Status (right). Lead cell = name 600 + "Created 18 Aug 2026" 11px `#94a3b8`. Score cell = 44px track `#eef1f5` with `#2563eb` fill at the score percentage, plus the numeric value. Header action: primary "New lead".

### Tab: Opportunities

Table `2.2fr 1.2fr 1fr 1fr 1fr` — Deal, Stage, Value (right), Prob. (right), Close date (right). Stage rendered as a neutral pill (`#f4f6f8`, `1px solid #e6eaf0`, `#475569`, 11.5px). Header right shows "Weighted forecast **KES 3.98M**" (12.5px `#64748b`, figure `#0f172a`/600) instead of a button.

### Tab: Projects

Two-column card grid, `gap:16px`. Each card padding 18px 20px, hover `border-color:#c9d3e0`. Title 13.5px/600; sub-line 11.5px `#64748b` — `PRJ-118 · Grace Wanjala`; status pill top-right. 16px below: 6px progress bar (track `#eef1f5`, fill `#2563eb`) plus percentage 11.5px `#475569`. Footer row 14px below: "Due 30 Sep 2026" and "18 / 25 tasks", both 11.5px `#94a3b8`.

Status → palette: On track = success, At risk = warning, Complete = info, Planning = neutral.

### Tab: Support

Four stat cards (padding 15px 18px; label 10.5px uppercase `#94a3b8`, value 20px/600): Open `4` · Breaching SLA `1` in `#b42318` · Avg. first response `2h 14m` · Satisfaction `4.6 / 5` in `#067647`.

Ticket table `90px 2.4fr 1fr 1.2fr 1.1fr` — Ref, Subject, Priority, Assignee, Updated (right). Ref 11.5px `#94a3b8`. Priority = 6px dot + label 11.5px/600 in the priority color: Critical `#b42318`, High `#b54708`, Medium `#175cd3`, Low `#475569`. Header action: primary "New ticket".

### Tab: Travels

Table `1.6fr 1.3fr 2fr 1.4fr 110px` — Traveller, Destination, Purpose, Dates, Status (right). Status pill: Approved = success, Pending = warning, Completed = neutral. Header action: primary "Request travel".

### Tab: Assigned Team

Three-column card grid, `gap:16px`. Each card padding 18px 20px: 38px initials avatar (`#eaf1fd`/`#1d4ed8`, 13px/600), name 13.5px/600, role 11.5px `#64748b`; 14px below, two label/value rows 12px (`#94a3b8` label, `#0f172a` / `#475569` values) — Responsibility, Since.

Below the grid, a full-width dashed card (`1px dashed #d7dee7`, radius 10, padding 20px): copy "Assign another team member to <Account>." 12.5px `#64748b` on the left, primary "Assign" button right.

### Unimplemented tabs

Any tab not in the list above renders a dashed placeholder card (`1px dashed #d7dee7`, padding 56px 20px, centered): tab name 14px/600 and a 12.5px `#64748b` line. Replace this with the real view — it exists only to keep the prototype navigable.

## Interactions & behavior

- **Tabs**: click switches the panel. Only the active panel is in the DOM. Tab state should live in the URL (`?tab=account-contracts` or a route segment) so a tab is linkable and survives refresh.
- **Follow toggle**: header button switches between "☆ Follow" and "★ Following" on click. Persist per user/account.
- **Hover states**: table rows `#f8fafc`; sidebar items `#f3f4f6`; secondary buttons `#f4f6f8`; primary buttons `#2563eb → #1d4ed8`; project cards raise border to `#c9d3e0`. No transition is specified in the prototype — a 120ms ease on `background-color` / `border-color` is appropriate.
- **Row click**: table rows should open the related record (contact, deal, ticket, contract). Not wired in the prototype.
- **Loading**: use the codebase's skeleton pattern. The KPI strip and each table should skeleton independently of the header card so identity renders immediately.
- **Empty states**: never print `—` in a card. Per-region rules: primary contact → "No primary contact set" + Add contact; documents → "No documents filed" + Attach; each table → a one-line reason plus its primary action. Detail fields inside "Account details" may show `—`, since the row still communicates which fields are unfilled.
- **Errors**: per-card error with a retry action; the page must still render identity and the tab bar.
- **Responsive**: at <1200px the Overview grid collapses to one column (right column below left, order preserved). Tab bar scrolls horizontally with no wrap. Tables become card lists below ~768px, or keep horizontal scroll if the app already does that elsewhere. The prototype is designed for desktop and not itself responsive.
- **Currency**: values are pre-formatted strings (`KES 4,200,000` in tables, `KES 4.20M` in KPI/summary tiles). Abbreviate in tiles, show full figures in tables.
- **Dates**: `30 Sep 2026` (day, short month, year). Relative form for recency ("4 days ago", "2h ago", "Yesterday", "1 week ago").

## State management

Prototype state (minimal by design):

- `activeTab: string` — default `"Overview"`; set by tab clicks. Move to the URL in the real implementation.
- `starred: boolean` — Follow toggle; must be persisted server-side.
- `showTimeline: boolean` — a prop, not user state: hides the Overview "Recent activity" card. This existed to compare a 2-card vs 3-card Overview. Decide one and drop the flag.

Data the real page needs, per region: account record (identity, details fields, logo, tier, owner); KPI aggregates (lifetime closed-won, open pipeline sum, next renewal date, last-contact date + channel + person); contacts; contracts (+ contracted-value, active-count, next-expiry aggregates); activities (paged); leads; opportunities (+ weighted forecast); projects; support tickets (+ open, SLA-breach, first-response, CSAT aggregates); travel requests; assigned team.

Fetch the account record and KPI aggregates on load; fetch each tab's collection lazily on first activation and cache it. Activities should page (prototype shows 6; Overview shows the newest 4).

## Design tokens

**Neutrals / surfaces**

| Token | Value | Use |
|---|---|---|
| page background | `#f8f9fb` | content area |
| surface | `#ffffff` | cards, sidebar, bars |
| surface muted | `#fafbfc` | table header rows |
| row hover | `#f8fafc` | table/list row hover |
| hover (chrome) | `#f3f4f6` | sidebar + top-bar controls |
| border | `#e6eaf0` | card borders |
| border (chrome) | `#e5e7eb` | sidebar/top-bar dividers |
| border strong | `#d1d5db` | input + secondary button borders |
| divider | `#eef1f5` | card header rules |
| divider light | `#f4f6f8` | in-card row rules |
| divider faint | `#f3f4f6` | sidebar rules |
| dashed border | `#d7dee7` | placeholder / empty cards |
| track | `#eef1f5` | progress bar tracks |

**Text**

`#0f172a` primary · `#111827` chrome primary · `#374151` sidebar item · `#475569` secondary · `#4b5563` sub-nav · `#64748b` muted · `#6b7280` chrome muted · `#94a3b8` labels & meta · `#9ca3af` placeholder · `#cbd5e1` separators.

**Accent (brand blue)**

`#2563eb` primary · `#1d4ed8` hover/active · `#eff6ff` active nav tint · `#eaf1fd` avatar fill · `#84b0f5` and `#cbdcf9` secondary pipeline segments.

**Brand red**

`#9b1c1c` top strip · `#d31c1c` wordmark.

**Status palettes** (`background` / `border` / `text`)

- Success: `#ecfdf3` / `#abefc6` / `#067647`; dot `#17b26a`
- Warning: `#fffaeb` / `#fedf89` / `#b54708`; alert card variant `#fffbf5` / `#f7e0bd` / `#7a3e0b`, body `#93500f`, dot `#f79009`, button fill `#fdf0da`
- Info: `#eff8ff` / `#b2ddff` / `#175cd3`
- Neutral: `#f4f6f8` / `#e6eaf0` / `#475569`
- Danger text: `#b42318`
- Logo tile placeholder: `#fdf2f2` / `#f4d6d6` / `#b91c1c`

**Typography** — the prototype uses `"Helvetica Neue", Helvetica, Arial, sans-serif`; use the app's existing family. `-webkit-font-smoothing: antialiased`.

| Role | Size / weight | Notes |
|---|---|---|
| Page title | 22 / 600 | `letter-spacing:-0.4px` |
| KPI value | 21 / 600 | `letter-spacing:-0.5px` |
| Summary value | 20 / 600 | `letter-spacing:-0.4px` |
| Card title | 13.5 / 600 | |
| Nav item | 13.5 / 400 | active 600 |
| Sub-nav, top-bar name | 13 / 400–600 | |
| Tab label | 13 / 450 | active 600 |
| Body, table cell | 12.5 / 400 | emphasis 500–600 |
| Meta, legend | 11.5 / 400 | |
| Small meta, file meta | 11 / 400 | |
| Section / column label | 10.5 / 600–700 | uppercase, `letter-spacing:.06–.08em` |
| Extension tile | 8.5–9 / 700 | uppercase |

**Spacing** — 2 · 3 · 6 · 7 · 8 · 10 · 11 · 12 · 14 · 16 · 18 · 20 · 22 · 24 · 28px. Card gap 16px; card padding 18px 20px (header 15px 20px, table rows 13px 20px); content padding 22px 28px 48px.

**Radii** — 3 (icon placeholder) · 5 (small tile, select) · 6 (chrome button, extension tile) · 7 (nav item, card button) · 9 (KPI strip) · 10 (card) · 999 (pill, Clock In). **Shadows** — none; the design separates surfaces with hairline borders only.

**Sizes** — sidebar 244px · top bar 60px · toolbar 52px · content max-width 1360px · buttons 30–34px tall · avatars 26/28/38/40px · logo tile 52px · progress bars 5–7px.

## Assets

- **Account logo** — the prototype uses a text placeholder tile (`AAR`). Wire to the stored account logo with an initials fallback.
- **Icons** — every icon in the prototype (sidebar, top bar, search, Clock In, logout, notification, theme) is a placeholder square or circle. Use the app's existing icon set: the reference screenshot shows the intended icon per nav item.
- No images, fonts, or third-party assets are introduced by this design.

## Files

- `Accounts Page.dc.html` — the full design prototype. Opens directly in a browser; click through all ten tabs. Its `defaultTab` and `showTimeline` values are authoring conveniences, not product features.
- `reference-current-page.png` — the page as it exists today, and the source of truth for the shell chrome and icon set.
