# Handoff: Task Detail Panel Redesign

## Overview

Redesign of the task detail view in an internal project/service management tool. The
current implementation is a small modal that repeats the task title three times, exposes
nine tabs above a body containing two short lines of text, spreads six read-only
properties across a wide two-column grid, and routes all editing through an
"Edit details" link.

Four directions were mocked. **Option 1c is the one selected for implementation** —
a full-page layout with a quiet section list on the left, task content in the middle,
and properties in a right-hand rail. Options 1a (tidied modal), 1b (side drawer) and
1d (chip header + collapsible section rows) are included in the same file as reference
alternatives, and are useful for lifting individual patterns (e.g. 1d's editable chip
row, 1b's inline sub-task list).

## About the Design Files

The files in this bundle are **design references created in HTML** — prototypes that
show intended look and behavior. They are **not production code to copy directly**.

`Task Panel Redesign.dc.html` is a single streaming HTML component file that renders
all four options side by side on a canvas, with an id badge on each
(`1a`, `1b`, `1c`, `1d`). It uses **inline styles only** — no stylesheet, no CSS
classes, no design tokens file. That is a constraint of the prototyping environment,
not a recommendation. In the real codebase, styling should follow whatever the project
already uses (CSS modules, Tailwind, styled-components, a component library, etc.).

The task is to **recreate design 1c in the target codebase's existing environment**
using its established patterns, component library, and conventions. If the project has
no established UI environment yet, pick the most appropriate framework and implement
there.

## Fidelity

**High-fidelity.** Colors, typography, spacing, radii and hover states are final and
specified exactly below. Recreate the UI faithfully, but substitute the codebase's own
primitives (Button, Avatar, Badge, Select, DatePicker, etc.) wherever equivalents exist
rather than hand-rolling spans. Copy is placeholder content standing in for real task
data — see "Content & copy" below for which strings are real vs. sample.

## Screen: Task detail — full page (option 1c)

### Purpose

Read a task's status at a glance; change its properties inline; work through sub-tasks,
comments and attachments without leaving the page or opening a second dialog.

### Overall layout

Outer container: `940px` wide in the mock, but this is a **full page** — in production
it should fill the available width with a max content width around `1280px`. Surface
`#ffffff`, border `1px solid rgba(15,23,42,.09)`, radius `14px`, shadow
`0 6px 24px -8px rgba(15,23,42,.18), 0 1px 2px rgba(15,23,42,.06)`. The radius and
shadow are artifacts of showing it as a card on a canvas — for a true full page, drop
both and let it sit flush.

Structure, top to bottom:

1. **Breadcrumb bar** — `padding: 12px 22px`, `border-bottom: 1px solid #eef1f5`,
   background `#fcfdfe`.
2. **Three-column body** — CSS grid, `grid-template-columns: 184px minmax(0,1fr) 250px`.
   - Left: section list. `padding: 20px 14px`, `border-right: 1px solid #eef1f5`,
     background `#fcfdfe`, `display:flex; flex-direction:column; gap:1px`.
   - Middle: task content. `padding: 26px 30px 30px`, `min-width: 0` (important — keeps
     long titles from blowing out the grid).
   - Right: properties rail. `padding: 24px 20px`,
     `border-left: 1px solid #eef1f5`, background `#fcfdfe`.

Both side columns should be sticky on scroll in production (`position: sticky; top: 0`);
the mock does not scroll so this is not shown.

### 1. Breadcrumb bar

Horizontal flex, `gap: 10px`, `align-items: center`.

| Element | Spec |
| --- | --- |
| Ancestor crumbs ("Projects", "Internal Projects") | 400 12.5px, `#94a3b8` |
| Separators (`/`) | `#cbd5e1` |
| Current task id ("TASK-485") | 500 12.5px, `#0f172a` |
| Category pill ("Project task") | `margin-left: 6px`, `padding: 3px 9px`, `border-radius: 999px`, background `#eef0fe`, border `1px solid #ddd9fd`, text 600 11.5px `#3730a3`; leading `6px × 6px` square dot, `border-radius: 2px`, background `#4f46e5`, `gap: 6px` |
| Close (`✕`) | `margin-left: auto`, 400 14px, `#94a3b8`, pointer cursor |

The category pill's dot color should key off the category (see "Task categorization"
below). On a full page, the close button becomes a back action or is dropped entirely.

### 2. Left column — section list

A vertical list replacing the current nine tabs. Sections that hold content are listed
first in normal weight; **sections that are empty are pushed below a divider and dimmed**,
so the user can see at a glance where there is actually something to read.

| Element | Spec |
| --- | --- |
| Group heading ("Sections") | 600 10.5px monospace, `letter-spacing: .06em`, uppercase, `#94a3b8`, `padding: 0 10px 8px` |
| Active item ("Overview") | `padding: 7px 10px`, `border-radius: 7px`, background `#eef0fe`, text 600 12.5px `#3730a3` |
| Inactive item | same box, text 500 12.5px `#475569`; hover background `#f1f5f9` |
| Item count badge | 600 11px monospace, `#94a3b8`, right-aligned via `justify-content: space-between` |
| Divider | `height: 1px`, background `#eef1f5`, `margin: 9px 10px` |
| "Empty" group heading | as group heading but `#cbd5e1` |
| Empty item | `padding: 6px 10px`, 400 12.5px, `#cbd5e1`; hover color `#475569` |

Order in the mock: Overview (active) · Sub-tasks `3` · Comments `2` · Meetings `1` ·
Resources — divider — Dependencies · Assisting · Activities · Issues.

The active/empty split must be **computed from data**, not hardcoded: a section with
zero items renders in the dimmed group.

### 3. Middle column — task content

| Element | Spec |
| --- | --- |
| Title (`h1`) | 700 26px / 1.25, `#0f172a`, `letter-spacing: -.015em`, `text-wrap: pretty`, `margin: 0` |
| Owner row | `margin-top: 12px`, flex, `gap: 8px`, `align-items: center` |
| Owner avatar | `24px` circle, background `#4f46e5`, white 600 10px initials |
| Owner text | 400 13px, `#64748b` — "Mohamed Ibrahim owns this task" |
| Divider in owner row | `1px × 14px`, background `#e2e8f0` |
| Involvement marker | flex, `gap: 6px`, 600 12.5px `#0f766e`, preceded by a `6px` circle in `#0f766e` — "You are assisting" |
| Description | `margin-top: 24px`, 400 15px / 1.75, `#334155`, `max-width: 62ch` |
| Section blocks | `margin-top: 26px` (24px for later ones), `padding-top: 22px`, `border-top: 1px solid #eef1f5` |
| Section heading | 600 13px, `#0f172a` |
| Section action ("＋ Add") | 500 12px, `#4f46e5`, pointer cursor, pushed right |

**Sub-task rows**: `display:flex; align-items:center; gap:11px; padding:9px 10px;
margin-left:-10px; border-radius:8px`; hover background `#f8fafc`. The negative
left margin lets the hover highlight bleed past the text baseline without shifting it.
Checkbox is `16px × 16px`, `border-radius: 4px` — unchecked `1.5px solid #cbd5e1`,
checked background `#0f766e` with a white `✓` at 600 9px. Row text 400 13.5px `#334155`;
completed rows are `#94a3b8` with `text-decoration: line-through`. A trailing due date
sits at `margin-left: auto`, 500 12px `#94a3b8`.

**Attachments**: horizontal flex, `gap: 12px`. Each card `132px` wide, border
`1px solid #e2e8f0`, `border-radius: 10px`, `overflow: hidden`; a `66px` tall thumbnail
area, then filename at 500 11.5px `#475569` in `padding: 8px 10px`. In the mock the
thumbnail is a striped placeholder
(`repeating-linear-gradient(135deg,#f1f5f9 0 8px,#e8edf3 8px 16px)`) — **replace with a
real file-type icon or document preview.** The add-file tile is the same footprint with
`1px dashed #cbd5e1`, 500 12px `#94a3b8`, hover border and text `#4f46e5`; it should be
a real drop target.

### 4. Right column — properties rail

Primary action sits at the top: full-width button, `padding: 10px`, `border: 0`,
`border-radius: 9px`, background `#4f46e5`, white 600 13px, hover `#4338ca`,
label "✓ Mark complete".

Below it (`margin-top: 18px`), a stack of property fields. Each field:
`padding: 11px 0`, `border-bottom: 1px solid #f1f5f9` (none on the last). Label is
400 11.5px `#94a3b8` with `margin-bottom: 4px` (6px for the two control fields).

Fields in order:

1. **Category** — four selectable chips, wrapping flex, `gap: 5px`.
   Selected: background `#eef0fe`, border `1px solid #ddd9fd`, 600 11.5px `#3730a3`.
   Unselected: background `#fff`, border `1px solid #e2e8f0`, 500 11.5px `#94a3b8`;
   hover text `#334155`, border `#94a3b8`. All chips `padding: 3px 8px`,
   `border-radius: 6px`. Options: Project task · Training · Support · Administrative.
2. **Your involvement** — segmented control. Track: `display:flex; padding:2px;
   background:#f1f5f9; border-radius:8px`. Each segment `flex:1`, centered,
   `padding: 5px 0`, `border-radius: 6px`, 500 11.5px `#64748b`. Selected segment:
   background `#fff`, shadow `0 1px 2px rgba(15,23,42,.1)`, 600 11.5px `#0f766e`.
   Options: Doing · Assisting · Tracking.
3. **Status** — pill, 600 12.5px `#3730a3`, background `#eef0fe`, `border-radius: 6px`,
   `padding: 3px 9px`. Value "In progress". Should open a status select.
4. **Deadline** — 500 13px `#0f172a` ("29 May 2026") with a 400-weight `#94a3b8`
   relative suffix (" · in 6 days"). The relative part is computed, and should turn
   `#b91c1c` when overdue.
5. **Priority** — `7px × 7px` square swatch (`border-radius: 2px`) + 500 13px `#0f172a`.
   Medium is `#d97706`.
6. **Assignees** — avatar row, `gap: 6px`, `24px` circles. Existing assignee `#0f766e`
   with white 600 10px initials; an add affordance as a `24px` circle with
   `1px dashed #cbd5e1` and a `＋` at 400 13px `#94a3b8`.
7. **Owed by** — 500 13px `#0f172a`, value "Us".
8. **Against estimate** — 400 13px `#cbd5e1` when unset, showing the literal
   "Not estimated". Unset values are deliberately lighter than set ones.

## Task categorization & involvement

These two concepts were added at the client's request and are the substantive new data
model work in this redesign.

**Category** — one value per task, from a fixed set: `Project task`, `Training`,
`Support`, `Administrative`. Surfaced twice: as a pill in the breadcrumb bar (read-only
glance) and as an editable chip group in the rail. Each category needs its own dot
color; the mock only specifies `Project task` = `#4f46e5`. Suggested completion,
matching the palette's chroma: Training `#0f766e`, Support `#b45309`,
Administrative `#64748b`. Confirm with the client before shipping.

**Involvement** — the current user's relationship to the task, one of `Doing`,
`Assisting`, `Tracking`. This is **per-user, not per-task**: two people opening the same
task can see different values. Surfaced twice: as green text on the owner line
("You are assisting") and as the segmented control in the rail. `Doing` should read
"You are doing this", `Tracking` "You are tracking this".

Both fields are strong candidates for board-level filtering ("show me everything I'm
tracking", "all Support tasks this week") — worth checking whether the list views need
the same vocabulary before finalizing the field names.

## Interactions & behavior

- **Every property in the rail edits in place.** No "Edit details" link, no second
  dialog. Clicking a value opens the appropriate control (select, date picker, people
  picker) anchored to the field; changes save on commit with optimistic UI.
- **Section list navigates**, it does not swap tab panels — clicking scrolls to that
  section in the middle column, and the active item follows the scroll position.
  Empty sections still navigate and show their empty state plus a create action.
- **Hover states** are specified per element above; all are `background` or `color`
  changes only. A `120ms ease` transition on `background-color` and `color` is
  appropriate; the mock declares none.
- **Sub-task checkboxes** toggle immediately, apply strikethrough, and re-sort completed
  items to the bottom of the list.
- **"Mark complete"** sets the task's status and should visibly reflect back into the
  Status field rather than only closing the view.
- **Attachment tile** accepts drag-and-drop as well as click-to-browse.
- **Responsive**: below roughly `1100px`, collapse the left section list to icons or a
  top row of pills; below `860px`, move the properties rail above the content as a
  two-column grid of fields. Not mocked.

## State

- `task` — id, title, description, category, status, deadline, priority, owner,
  assignees, owedBy, estimate.
- `involvement` — current user's relationship to this task (`doing | assisting | tracking`).
- `sections` — per-section item counts, driving both ordering and the empty/non-empty
  split in the left column.
- `activeSection` — derived from scroll position, overridden on click.
- `subtasks`, `comments`, `attachments`, `meetings` — lists, each independently loadable.
- Per-field `saving` / `error` state for inline edits.

Counts in the left column must be loaded with the task, not lazily per section —
otherwise the empty/non-empty split cannot be rendered on first paint.

## Design tokens

**Colors**

| Token | Hex | Use |
| --- | --- | --- |
| Canvas | `#eef1f5` | page background behind the panel |
| Surface | `#ffffff` | main panel |
| Surface sunken | `#fcfdfe` | breadcrumb bar, side columns |
| Row hover | `#f8fafc` | sub-task and field row hover |
| Fill muted | `#f1f5f9` | segmented track, item hover, badges |
| Line | `#eef1f5` | structural borders |
| Line soft | `#f1f5f9` / `#f4f6f9` | field dividers |
| Line strong | `#e2e8f0` | cards, inputs, dashed placeholders |
| Ink | `#0f172a` | titles, values |
| Ink body | `#334155` | description, row text |
| Ink muted | `#64748b` | secondary text |
| Ink faint | `#94a3b8` | labels, counts |
| Ink disabled | `#cbd5e1` | unset values, empty sections |
| Accent | `#4f46e5` | primary action, links, active category |
| Accent hover | `#4338ca` | primary button hover |
| Accent deep | `#3730a3` | text on accent-soft |
| Accent soft | `#eef0fe` | active pill/chip backgrounds |
| Accent soft border | `#ddd9fd` | active pill/chip borders |
| Success | `#0f766e` | completed checks, involvement, one avatar |
| Warning | `#d97706` | medium priority swatch |
| Danger | `#b91c1c` | destructive hover, overdue (proposed) |

**Typography** — single family, `Public Sans` (Google Fonts, weights 400/500/600/700),
falling back to `system-ui, sans-serif`. Monospace (`ui-monospace, Menlo, monospace`)
is used only for ids, counts and uppercase micro-labels.

Scale as used: 26/1.25 700 (page title) · 15/1.75 400 (description) · 13.5 400
(sub-task rows) · 13 400–600 (values, section headings) · 12.5 400–600 (breadcrumbs,
list items, pills) · 11.5 400–600 (rail labels, chips) · 11 600 mono (counts) ·
10.5 600 mono uppercase `letter-spacing: .06em` (group headings).

**Spacing** — 1 · 2 · 4 · 5 · 6 · 8 · 9 · 10 · 11 · 12 · 14 · 18 · 20 · 22 · 24 · 26 ·
30px. Column widths `184 / 1fr / 250`.

**Radius** — 2 (dots) · 4 (checkbox, mono badges) · 6 (chips, pills) · 7 (list items) ·
8 (rows, segmented track) · 9 (buttons) · 10 (cards) · 14 (panel) · 999 (category pill).

**Shadow** — panel `0 6px 24px -8px rgba(15,23,42,.18), 0 1px 2px rgba(15,23,42,.06)`;
primary button `0 1px 2px rgba(15,23,42,.14)`; segmented thumb
`0 1px 2px rgba(15,23,42,.1)`.

## Assets

None real. Two placeholders to replace:

- **Attachment thumbnail** — striped gradient standing in for a file-type icon or
  document preview.
- **Icon glyphs** — the mock uses text characters (`✓ ✕ ⋯ ⤢ ＋ › ⌄ ⌫ ⧉`) where the
  codebase should use its real icon set. Sizes are 12–16px, colored to match
  surrounding text.

Avatars are initials on solid fills; swap for the app's real avatar component.

## Content & copy

Real, from the client's screenshot: task title "KNS Internal Projects and Service Review
Meeting", owner "Mohamed Ibrahim", status "In progress", deadline 29 May 2026, priority
"Medium", "Owed by: Us", "Not estimated", and the nine section names (Description,
Sub-tasks, Dependencies, Assisting, Comments, Resources, Meetings, Activities, Issues).

Invented as sample data — replace, do not ship: the description text, all three
sub-tasks, "Q2-agenda.pdf", the Joyce K comment, the meeting time, "TASK-485", and the
"created 12 May" date.

## Files

- `Task Panel Redesign.dc.html` — all four options on one canvas. Option 1c is marked
  with a `1c` badge and is the one to build; it is the third block in the file, wrapped
  in `<div class="dv-opt" id="1c">`. Open in a browser to view.
